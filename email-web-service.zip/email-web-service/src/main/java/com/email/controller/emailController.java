package com.email.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.email.model.EmailModel;
import com.email.service.emailService;

@RestController
public class emailController {

	@Autowired
	private emailService emailService;
	
	
	@GetMapping("/welcome")
	public String welcome() {
		return "welcom to email api";
	}
	
	
	@PostMapping("/sendmail")
	public ResponseEntity<?> sendEmail(@RequestBody EmailModel request){
		
		System.out.println(request);
	boolean result=	this.emailService.emailSend(request.getSubject(),request.getMessage(),request.getto());
		if(result) {
			return ResponseEntity.ok("Email send successfully..");
		}
	return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("somthing went wrong...");
	}
}
